Generate the training and test data by running the python2 script p_2_generate_chessboard.py

The model is in p_3_model.py

